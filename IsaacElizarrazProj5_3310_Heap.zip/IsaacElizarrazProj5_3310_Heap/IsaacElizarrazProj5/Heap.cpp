#include <iostream>
#include "Heap.h"
using namespace std;

Heap::Heap()
{
	size = 0;
	arr[0] = 0;
}

void Heap::empty()
{
	if (size == 0)
		cout << "\nThe heap array is empty.\n";
	else
		cout << "\nThe heap array is not empty.\n";
}

void Heap::insert(int d)
{
	arr[size] = d;
	size++;
}

int Heap::retrieve()
{
	return arr[size - 1];
	cout << "\n\nThe largest value in heap array is: " <<  endl;
}

void Heap::remove()
{
	arr[size - 1] = NULL;
	size--;
	cout << "\nRemoving largest value\n";
}

void Heap::display()
{
	cout << "The contents of the heap array:\n";
	for (int i = 0; i < size; i++)
		cout << arr[i] << " ";
}

void Heap::heap(int root)
{
	int left = 2 * root + 1;
	int right = 2 * root + 2;
	if (arr[left] > arr[root])
		swap(arr[left], arr[root]);
	if (arr[right] > arr[root])
		swap(arr[right], arr[root]);
}

void Heap::sort()
{
	for (int i = size / 2 - 1; i >= 0; i--)
		heap(i);
	for (int i = size - 1; i >= 0; i--)
	{
		swap(arr[0], arr[i]);
		heap(0);
	}
	swap(arr[0], arr[1]);
	swap(arr[1], arr[2]);
	cout << "\nSorting the array\n\n";
}