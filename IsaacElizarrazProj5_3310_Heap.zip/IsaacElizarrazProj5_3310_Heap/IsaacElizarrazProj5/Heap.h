#pragma once
#define CAPACITY 999
class Heap
{
public:
	int size;
	int arr[CAPACITY];
	void empty();
	void insert(int data);
	int retrieve();
	void remove();
	void display();
	void sort();
	void heap(int data);
	Heap();
};