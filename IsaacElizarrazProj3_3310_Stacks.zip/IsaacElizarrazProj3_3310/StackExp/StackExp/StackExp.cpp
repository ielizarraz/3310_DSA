// StackExp.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
#include "IntStack.h"
#include "Ostack.h"
#include <string>
string postFix(string exp);
int postfixevaluation(string exp);

int main()
{
	string infixexp = "(1+6/2*(1+1)-3)";
	string postfixexp = postFix(infixexp);
	cout << postfixexp;
	cout << endl << "The answer to the postfix expression is : "  << postfixevaluation(postfixexp);

	string infixexp2 = "(3+(4/2)*(2+3)-6)";
	string postfixexp2 = postFix(infixexp2);
	cout << postfixexp2;
	cout << endl << "The answer to the postfix expression is : " << postfixevaluation(postfixexp2);
}
 
string postFix(string exp)
{
	Node* token = new Node('\0');
	char priority;
	string postfix_exp = "";
	Ostack opstack;
	for (int i = 0; i < exp.length(); i++)
	{
		Node* token = new Node('\0');
		token->chardata = exp[i];
		switch (token->chardata)
		{

		case ' ':
			opstack.stack_size -= 1;
			break;
			
		case '(': opstack.push(token);
				  opstack.display();
			break;
		case '+': 
	
			while (opstack.stack_top->chardata == '-' || opstack.stack_top->chardata == '/' || opstack.stack_top->chardata == '*')
			{
				if (opstack.stack_top->chardata == '-')
				{
					priority = opstack.pop()->chardata;
					postfix_exp = postfix_exp + priority;
					opstack.display();
				}
				else if (opstack.stack_top->chardata == '/')
				{
					priority = opstack.pop()->chardata;
					postfix_exp = postfix_exp + priority;
					opstack.display();

				}
				else

				{
					priority = opstack.pop()->chardata;
					postfix_exp = postfix_exp + priority;
					opstack.display();

				}
			}
			opstack.push(token);
			opstack.display();
			break;

			
		case '-':
			while (opstack.stack_top->chardata == '+' || opstack.stack_top->chardata == '/' || opstack.stack_top->chardata == '*') 
			{
				if (opstack.stack_top->chardata == '+')
				{
					priority = opstack.pop()->chardata;
					postfix_exp = postfix_exp + priority;
					opstack.display();
				}
				else if (opstack.stack_top->chardata == '/')
				{
					priority = opstack.pop()->chardata;
					postfix_exp = postfix_exp + priority;
					opstack.display();
					
				}
				else

				{
					priority = opstack.pop()->chardata;
					postfix_exp = postfix_exp + priority;
					opstack.display();

				}
			}
			  
				opstack.push(token);
				opstack.display();
				break;
		

		case '*':
			if (opstack.stack_top->chardata == '/')
			{
				priority = opstack.pop()->chardata;
				opstack.push(token);
				postfix_exp = postfix_exp + priority;

				opstack.display();
				break;
			}
			else
			{
				opstack.push(token);
				opstack.display();
				break;
			}

		case '/':
			if (opstack.stack_top->chardata == '*')
			{
				priority = opstack.pop()->chardata;
				opstack.push(token);
				postfix_exp = postfix_exp + priority;
				opstack.display();
				break;
			}
			else
			{
				opstack.push(token);
				break;
			}

		case ')':
			while (opstack.stack_top->chardata != '(')
			{
				token = opstack.pop();
				postfix_exp = postfix_exp + token->chardata;
				
			}
			opstack.pop();
			opstack.display();
			break;
		
		
		case '%':
			opstack.push(token);

			break;
			default:
				postfix_exp = postfix_exp + token->chardata;
				opstack.display();
				break;
		}
	}
	return postfix_exp;
}

int postfixevaluation(string exp)
{
	Node* token = new Node('\0');
	double total;
	IntStack istack;
	for (int i = 0; i < exp.length(); i++)
	{
		Node* token = new Node('\0');
		token->chardata = exp[i];
		switch (token->chardata)
		{



		case '+':
			
			token->data = (istack.pop()->data) + (istack.pop()->data);
			istack.push(token);
			istack.display();
			break;


		case '-':
			token->data = istack.pop()->data;
			token->data = (istack.pop()->data) - (token->data);
			istack.push(token);
			istack.display();
			break;


		case '*':
			
			token->data = (istack.pop()->data) * (istack.pop()->data);
			istack.push(token);
			istack.display();
			break;
		case '/':
			token->data = istack.pop()->data;
			token->data = (istack.pop()->data) / (token->data);
			istack.push(token);
			istack.display();
			break;

		default:
			token->data = token->chardata - 48;
			istack.push(token);
			istack.display();
			break;
		}	
		
	}
	return  istack.pop()->data;
}