#pragma once
#define CAPACITY 128
#include "Node.h"
class IntStack 
{
public:
	
	int stack_size;
	Node* stack_top;
	IntStack();
	bool empty();
	void push(Node* item);
	Node* pop();
	void display();
};