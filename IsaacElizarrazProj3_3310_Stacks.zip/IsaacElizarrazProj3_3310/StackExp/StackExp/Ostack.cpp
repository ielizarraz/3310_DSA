#include <iostream>
#include "OStack.h"
using namespace std;
typedef char StackElement;

Ostack::Ostack()
{
	stack_top = '\0';
	stack_size = 0;
}
bool Ostack::empty()
{
	if (stack_size != 0)
		return false;
	else
		return true;
}
void Ostack::push(Node* item)
{
	if (stack_top == '\0') 
	{
		stack_top = item;
	}
	else
	{
		item->next = stack_top;
		stack_top = item;
	}
	stack_size++;
	
}
Node* Ostack::pop()
{
	if (!empty())
	{
		Node* popped_node = stack_top;
		stack_top = stack_top->next;
		stack_size--;
		return popped_node;
	}
	else
	{
		cout << "\n The stack is empty";
		return '\0';
	}
}
void Ostack::display()
{
	if (!empty())
	{
		Node* current_node;
		current_node = stack_top;
		cout << "\nThe stack contents are (from top to bottom): " << "\t stack size " <<stack_size << " ";
		while (current_node != '\0')
		{
			cout << current_node->chardata << ", ";
			current_node = current_node->next;
		}
	}
	else
		cout << "\n The stack is empty \n";
}