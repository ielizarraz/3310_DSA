#include <iostream>
using namespace std;
#include "IntStack.h";
#include "Node.h"


#define CAPACITY 128

IntStack::IntStack()
{
	stack_top = '\0';
	stack_size = 0;
}
bool IntStack::empty()
{
	if (stack_size != 0)
		return false;
	else
	    return true;
}
void IntStack::push(Node* item)
{
	if (stack_size == '\0') {
		stack_top = item;
	}
	else
	{
		item->next = stack_top;
		stack_top = item;
	}
	stack_size++;
}
Node* IntStack::pop()
{	
	if (!empty())
	{
		Node* popped_node = stack_top;
		stack_top = stack_top->next;
		stack_size--;
		return popped_node;
	}
	else
	{
		cout << "The stack is empty\n";
		return 0;
	}
}
void IntStack::display()
{
	if (!empty())
	{
		Node* current_node;
		current_node = stack_top;
		cout << "\n The stack contents are (from top to bottom):	";
		while (current_node != '\0')
		{
			cout << current_node->data << " ";
			current_node = current_node->next;
		}
	}
	else
		cout << "The stack is empty \n";
}