#pragma once

class Node
{
public: 
	int data;
	char chardata;
	Node* next;
	Node();
	Node(int d);
	Node(char d);
};