#pragma once
#include "Node.h"

typedef char StackElement;
class Ostack
{
public:
	Node* stack_top;
	int stack_size;
	Ostack();
	bool empty();
	void push(Node* item);
	Node* pop();
	void display();
};