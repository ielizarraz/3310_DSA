#pragma once
#include <iostream>
using namespace std;
#include "Node.h"
Node::Node() {
	chardata = '\0';
	data = 0;
	next = '\0';
}
Node::Node(int d)
{
	data = d;
	next = '\0';
}
Node::Node(char d)
{
	chardata = d;
	next = '\0';
}
