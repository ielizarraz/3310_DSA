#pragma once
#include <iostream>
#include "Node.h"


Node::Node(int d)
{
	occurances = '\0';
	parent = '\0';
	left = '\0';
	right = '\0';
	score = d;
}