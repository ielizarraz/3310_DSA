// Nov42019ECE3310.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "Node.h"
#include "BST.h"
using namespace std;
void search(Node* n, int d);

int main()
{
	Node* a = new Node(11);
	Node* b = new Node(14);
	Node* c = new Node(8);
	Node* d = new Node(14);
	Node* e = new Node(14);
	Node* f = new Node(20);
	Node* g = new Node(14);
	Node* h = new Node(3);
	Node* i = new Node(11);
	Node* j = new Node(3);
	Node* k = new Node(11);
	Node* l = new Node(11);
	Node* m = new Node(17);
	Node* n = new Node(17);
	Node* o = new Node(15);
	Node* p = new Node(20);
	Node* q = new Node(20);
	Node* r = new Node(10);
	Node* s = new Node(15);
	Node* t = new Node(20);
	Node* u = new Node(14);
	Node* v = new Node(20);
	Node* w = new Node(17);
	Node* x = new Node(11);
	Node* y = new Node(19);
	Node* z = new Node(16);




	BST mybst(a);
	mybst.insert(a, b);
	mybst.insert(a, c);
	mybst.insert(a, d);
	mybst.insert(a, e);
	mybst.insert(a, f);
	mybst.insert(a, g);
	mybst.insert(a, h);
	mybst.insert(a, i);
	mybst.insert(a, j);
	mybst.insert(a, k);
	mybst.insert(a, l);
	mybst.insert(a, m);
	mybst.insert(a, n);
	mybst.insert(a, o);
	mybst.insert(a, p);
	mybst.insert(a, q);
	mybst.insert(a, r);
	mybst.insert(a, s);
	mybst.insert(a, t);
	mybst.insert(a, u);
	mybst.insert(a, v);
	mybst.insert(a, w);	
	mybst.insert(a, x);
	mybst.insert(a, y);
	mybst.insert(a, z);



	mybst.inorder(a);
	cout << endl;
    mybst.postorder(a);
	cout << endl;
	mybst.preorder(a);
	search(a, 16);
	search(a, 13);
	mybst.replace(a, e, 13); cout << endl;
	mybst.inorder(a);
	search(a, 13);



}
void search(Node* n, int d)
{	
	if (n->score == NULL)
	{
		cout << "\nsorry the amount does not exist within the tree\n";
	}
	if (n->score == d)
	{
		cout << "\n\nThe data " << d << " exists with " << n->occurances << " occurances in the score tree.\n";
	}
	else {
		if (n->left==NULL && n->right == NULL)
		{
			cout << "\n\nsorry the amount does not exist within the tree\n";
		}

		else if (n->score > d && n->left != NULL)
		{
			search(n->left, d);
		}
		else if (n->score < d && n->right != NULL) {
			search(n->right, d);
		}
		else
		{
			cout << " \n\nsorry the amount " << d << " does not exist within the tree\n";
		}
	}
}
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
