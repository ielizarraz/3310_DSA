
#pragma once
#include <iostream>
#include "Node.h"
using namespace std;

class BST
{
public:
	Node* root;
	BST(Node* something);
		bool search(Node* root, int key);
		void insert(Node* root, Node* n);
		void remove(Node* n);
		void inorder(Node* r);
		void preorder(Node* r);
		void postorder(Node* r);
		void replace(Node* root , Node* r, int newdata);

};