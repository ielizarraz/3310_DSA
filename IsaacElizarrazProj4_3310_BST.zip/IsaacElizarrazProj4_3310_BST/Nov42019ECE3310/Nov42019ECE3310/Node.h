#pragma once
#include <iostream>
using namespace std;

class Node {
public:
	Node(int d);
	int score;
	int occurances;
	Node* parent;
	Node* right;
	Node* left;
	
};