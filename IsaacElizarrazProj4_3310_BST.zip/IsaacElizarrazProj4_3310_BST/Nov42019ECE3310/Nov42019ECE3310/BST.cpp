
#include <iostream>
#include "Node.h"
#include "BST.h"
using namespace std;
BST::BST(Node* n)
{
	root = n;
}
bool BST::search(Node* root, int key)
{
	if (root == NULL)
	{
		return false;
	}
	else
	{
		if (root->score == key) {
			return true;
		}
		else
		{
			if (root->score > key) {
				search(root->left, key);
			}
			else
			{
				search(root->right, key);
			}
		}
	}
}
void BST::insert(Node* root, Node* n)
{
	if (root->score == n->score)
	{
		cout << "\n the data " << n->score << " is already in the tree, adding an occurance\n";
		root->occurances++;
	}
	else
	{
		if (root->score > n->score)
		{
			if (root->left == NULL) {
				root->left = n;
				n->parent = root;
				n->occurances++;
			}
			else {
				insert(root->left, n);
			}
		}
		else
		{
			if (root->right == NULL) {
				root->right = n;
				n->parent = root;
				n->occurances++;
			}
			else {
				insert(root->right, n);
			}
		}
	}
}


void BST::remove(Node* n)
{// case 1 : leaf
	if (n->occurances > 1)
	{
		n->occurances--;
	}
	else { 
		if ((n->left == NULL) && (n->right == NULL))
		{
			if (n->parent != NULL) 
			{
				if (n->score > n->parent->score)
				{
					n->parent->right = NULL; 
				}
				else {
					n->parent->left = NULL; 
				}
			}
			else {
				root = NULL;
				//cout << "\n the tree has been emptied \n";

			}
		}
		// case 2: one-child
		Node* predecessor;
		if ((n->right != NULL) && (n->left == NULL))
		{

			if (n->score > n->parent->score) {

				if (n->parent->left != NULL)
				{
					predecessor = n->parent->left;
					predecessor->parent = n->parent->parent;
					while (predecessor->right->right != NULL)
					{
						predecessor = predecessor->right;

					}
					predecessor->right = n->parent;
					if (n->parent->parent->score < n->parent->score)
					{
						n->parent->parent->right = n->parent->left;
						n->parent->parent = predecessor;
						n->parent->right = n->right;
						n->right->parent = n->parent;
					}


				}
				else
				{
					n->parent->right = n->right;
					n->right->parent = n->parent;
				}
				//notfinished, need to do situation where score is less than parent meaning left side tree is n
			}
			else {
				n->parent->left = n->right;
				n->right->parent = n->parent;
			}


		}
		if ((n->right == NULL) && (n->left != NULL))
		{
			
			if (n->score > n->parent->score)
			{
				predecessor = n->left;
				while (predecessor->right->right != NULL)
				{
					predecessor = predecessor->right;

				}
				n->parent->right = predecessor->right;
				n->left->parent = predecessor->right;
				predecessor->parent - n->parent;

			}
			else
			{
				predecessor = n->left;
				while (predecessor->right->right != NULL)
				{
					predecessor = predecessor->right;

				}
				n->parent->left = predecessor->right;
				n->left->parent = predecessor->right;
				predecessor->parent - n->parent;
			}
		}

		// case 3 : two children

		Node* pred;
		if ((n->right != NULL) && (n->left != NULL))
		{
			pred = n->left;
			while (pred->right->right != NULL)
			{
				pred = pred->right;
			}
			n->score = pred->score;
			pred->right = NULL;
		
		}
	}
}

// other remove func
/*void BST::remove(Node* n)
{// case 1 : leaf
	if ((n->left == NULL) && (n->right == NULL))
	{
		if (n->parent != NULL)
		{
			if (n->data > n->parent->data)
			{
				n->parent->right = NULL;
			}
			else {
				n->parent->left = NULL;
			}
		}
		else {
			root = NULL;
			cout << "\n the tree is empty now \n";

		}
	}
// case 2: one-child
	if ((n->right != NULL) && (n->left == NULL))
	{
		if (n->data > n->parent->data)
			n->parent->right = n->right;
		else
			n->parent->left = n->right;
	}
	if ((n->right == NULL) && (n->left != NULL))
	{
		if (n->data > n->parent->data)
			n->parent->right = n->left;
		else
			n->parent->left = n->left;
	}
	
// case 3 : two children

	Node* succesor;
	if ((n->right != NULL) && (n->left != NULL))
	{
		succesor = n->right;
		while (succesor->left != NULL)
		{
			succesor = succesor->left;
		}
		n->data = succesor->data;
		if (succesor->right != NULL)
		{
			succesor->parent->left = succesor->right;
			succesor->right->parent = succesor->parent;
		}
	}
}*/

void BST::replace(Node* root, Node* n, int newdata)
{	
	remove(n);
	n->score = newdata;
	insert(root, n);
}
void BST::inorder(Node* r)
{
	if (r != NULL) {
		inorder(r->left);
		cout << r->score << "\t";
		inorder(r->right);
	}
}

void BST::preorder(Node* r)
{
	if (r != NULL) {
		cout << r->score << "\t";
		preorder(r->left);
		preorder(r->right);
	}
}

void BST::postorder(Node* r)
{
	if (r != NULL) {
		postorder(r->left);
		postorder(r->right);
		cout << r->score << "\t";
	}
}

