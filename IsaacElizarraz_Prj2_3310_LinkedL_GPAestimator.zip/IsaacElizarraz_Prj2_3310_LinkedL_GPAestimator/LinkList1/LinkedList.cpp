#include <iostream>
using namespace std;
#include "Node.h"
#include "LinkedList.h"
CourseList::CourseList()
{

	Node* headnode = new Node("ECE 1101", "B", 4);
	first = headnode;
}
bool CourseList::empty()
{
	if (first == '\0')
		return true;
	else
		return false;
}
void CourseList::insert_first(Node* newnode)
{
	if (!empty())
	{
		first->pred = newnode;
		newnode->next = first;
	}
 first = newnode;
}
void CourseList::insert(Node* newnode, Node* previous)
{
	if (previous->next!='\0')
		previous->next->pred = newnode;
	newnode->pred = previous;
	newnode->next = previous->next;
	previous->next = newnode;
}
void CourseList::erase(Node* target)
{
	if (target->pred!='\0')
		target->pred->next = target->next;
	if (target->next!='\0')
		target->next->pred = target->pred;
	target->next = '\0';
	target->pred = '\0';
}
void CourseList::display()
{
	Node* current;
	if (first != '\0')
	{
		current = first;
		while (current->next!='\0')
		{
			cout << current->coursename << " :\t ";
			cout << "Grade Received: " << current->grade << "\t ";
			cout << "Units: " << current->units << " \n";
			current = current->next;
		}  
		cout << current->coursename << " :\t ";
		cout << "Grade Received: " << current->grade << "\t ";
		cout << "Units: " << current->units << " ";
	}
		
}

