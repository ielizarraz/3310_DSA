#include <iostream>
using namespace std;
#include "Node.h"
#include "LinkedList.h"
#include "GPAestimator.h"

GPAEstimator::GPAEstimator()
{
	Composition = '\0';
}


double GPAEstimator::GPACalculation(CourseList* gpaentry)
{
	Node* current;

	double sumnum = 0;
	double sumdenom = 0;
	double unitequiv = 0;

	if (gpaentry->first != '\0')
	{
		current = gpaentry->first;
		while (current->next != '\0')
		{
			if (current->grade == "A") {
				unitequiv = 4;
			}
			else if (current->grade == "A-") {
				unitequiv = 3.7;
			}
			else if (current->grade == "B+") {
				unitequiv = 3.3;
			}
			else if (current->grade == "B") {
				unitequiv = 3.0;
			}
			else if (current->grade == "B-") {
				unitequiv = 2.7;
			}
			else if (current->grade == "C+") {
				unitequiv = 2.3;
			}
			else if (current->grade == "C") {
				unitequiv = 2.0;
			}
			else {
				unitequiv = 1.7;
			}

			sumnum += (current->units * unitequiv);
			sumdenom += current->units;
			current = current->next;
		}
		sumnum += (current->units * unitequiv);
		sumdenom += current->units;
	}



	return sumnum / sumdenom;

}