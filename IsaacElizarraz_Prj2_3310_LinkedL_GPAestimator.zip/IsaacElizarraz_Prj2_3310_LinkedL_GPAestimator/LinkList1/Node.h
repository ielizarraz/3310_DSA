#pragma once
class Node
{public:
	string coursename;
	string grade;
	double units;
	Node* next;
	Node* pred;
	Node(string coursename, string coursegrade, double units);
};