#pragma once
#include <iostream>
using namespace std;
#include "Node.h"
Node::Node(string coursename, string coursegrade, double units)
{
	this->coursename = coursename;
	this->grade = coursegrade;
	this->units = units;
	next = '\0';
	pred = '\0';
}