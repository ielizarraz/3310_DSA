#pragma once
#include <iostream>
using namespace std;
#include "Node.h"
class CourseList
{ public:
	Node* first;
	CourseList();
	bool empty();
	void insert_first(Node* newnode);
	void insert(Node* newnode, Node* pred);
	void erase(Node* target);
	void display();
};
