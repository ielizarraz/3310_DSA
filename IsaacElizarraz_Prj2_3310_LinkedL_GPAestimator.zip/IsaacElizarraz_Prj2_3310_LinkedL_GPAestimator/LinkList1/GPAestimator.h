#pragma once
#include <iostream>
using namespace std;
#include "Node.h"
#include "LinkedList.h"

class GPAEstimator
{
public:
	CourseList* Composition;
	GPAEstimator();
	double GPACalculation(CourseList* entry);
};