// LinkList1.cpp : This file contains the 'main' function. Program execution begins and ends there.


#include <iostream>
using namespace std;
#include "Node.h"
#include "LinkedList.h"
#include "GPAEstimator.h"
int main()
{
	Node* n1 = new Node("ECE 1101", "B" , 4);
	Node* n2 = new Node("ECE 2101", "B+", 4);
	Node* n3 = new Node("ECE 3101", "A-", 4); 
	Node* n4 = new Node("ECE 2310", "B+", 4);
	Node* n5 = new Node("ECE 3310", "A", 4);
	Node* n6 = new Node("Math 214", "B", 2.34);
	Node* n7 = new Node("Math 215", "C-", 2.34);  // This node will be deleted
	Node* n8 = new Node("Math 224", "B", 2.34);
	Node* n9 = new Node("ECE 204", "B+", 2.34);
	Node* n10 = new Node("ECE 299", "B-", 2.34);
	Node* insert = new Node("ECE 2200", "A-", 4.0); // This node will be added
	CourseList* mylist = new CourseList();
	GPAEstimator estimate;
	
	
	
	
	mylist->insert(n2, mylist->first);
	mylist->insert(n3, n2);
	mylist->insert(n4, n3);
	mylist->insert(n5, n4);
	mylist->insert(n6, n5);
	mylist->insert(n7, n6);
	mylist->insert(n8, n7);
	mylist->insert(n9, n8);
	mylist->insert(n10, n9);
	mylist->display();
	
	estimate.Composition = mylist;
	cout << endl << endl << "The average gpa across these classes is : " << estimate.GPACalculation(estimate.Composition) << endl;

	mylist->erase(n7);
	mylist->display();
	estimate.Composition = mylist;
	cout << endl << endl << "The average gpa across these classes is : " << estimate.GPACalculation(estimate.Composition) << endl;
	cout << endl << endl;
	mylist->insert(insert, n6);
	mylist->display();
	estimate.Composition = mylist;
	cout << endl << endl << "The average gpa across these classes is : " << estimate.GPACalculation(estimate.Composition) << endl;
}
	
	

	
 